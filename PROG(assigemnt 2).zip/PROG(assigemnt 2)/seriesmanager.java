/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author RC_Student_lab
 */
 import java.util.ArrayList;
import java.util.Scanner;

public class seriesmanager {
    private static ArrayList<Series> seriesList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("LATEST SERIES - 2025");
        System.out.println("*******************************");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");

        String input = scanner.nextLine();
        if (!input.equals("1")) {
            System.out.println("Application exited.");
            return;
        }

        displayMenu();
    }

    private static void displayMenu() {
        while (true) {
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new series");
            System.out.println("(2) Search for a series");
            System.out.println("(3) Update series");
            System.out.println("(4) Delete a series");
            System.out.println("(5) Print series report");
            System.out.println("(6) Exit Application");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    captureSeries();
                    break;
                case "2":
                    searchSeries();
                    break;
                case "3":
                    updateSeries();
                    break;
                case "4":
                    deleteSeries();
                    break;
                case "5":
                    printReport();
                    break;
                case "6":
                    System.out.print("Are you sure you want to exit? (Yes/No): ");
                    if (scanner.nextLine().equalsIgnoreCase("Yes")) {
                        System.out.println("Exiting...");
                        return;
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void captureSeries() {
        System.out.println("\n--- Capture New Series ---");

        System.out.print("Enter series ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter series name: ");
        String name = scanner.nextLine();

        int ageRestriction = getValidNumber("Enter age restriction (2-18): ", 2, 18);
        int episodes = getValidNumber("Enter number of episodes: ", 1, Integer.MAX_VALUE);

        seriesList.add(new Series(id, name, ageRestriction, episodes));
        System.out.println("Series added successfully!");
    }

    private static int getValidNumber(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int num = Integer.parseInt(scanner.nextLine());
                if (num >= min && num <= max) {
                    return num;
                }
                System.out.println("Please enter a number between " + min + " and " + max);
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Please try again.");
            }
        }
    }

    private static void searchSeries() {
        System.out.println("\n--- Search Series ---");
        System.out.print("Enter series ID: ");
        String id = scanner.nextLine();

        for (Series s : seriesList) {
            if (s.getId().equals(id)) {
                System.out.println("\nSeries found:\n" + s);
                return;
            }
        }
        System.out.println("Series not found.");
    }

    private static void updateSeries() {
        System.out.println("\n--- Update Series ---");
        System.out.print("Enter series ID: ");
        String id = scanner.nextLine();

        for (Series s : seriesList) {
            if (s.getId().equals(id)) {
                System.out.println("\nCurrent details:\n" + s);

                System.out.print("New name (blank to keep): ");
                String name = scanner.nextLine();
                if (!name.isEmpty()) s.setName(name);

                System.out.print("New age restriction (blank to keep): ");
                String ageStr = scanner.nextLine();
                if (!ageStr.isEmpty()) s.setAgeRestriction(Integer.parseInt(ageStr));

                System.out.print("New episodes (blank to keep): ");
                String epStr = scanner.nextLine();
                if (!epStr.isEmpty()) s.setNumberOfEpisodes(Integer.parseInt(epStr));

                System.out.println("Series updated!");
                return;
            }
        }
        System.out.println("Series not found.");
    }

    private static void deleteSeries() {
        System.out.println("\n--- Delete Series ---");
        System.out.print("Enter series ID: ");
        String id = scanner.nextLine();

        for (int i = 0; i < seriesList.size(); i++) {
            if (seriesList.get(i).getId().equals(id)) {
                System.out.print("Confirm delete " + id + "? (Yes/No): ");
                if (scanner.nextLine().equalsIgnoreCase("Yes")) {
                    seriesList.remove(i);
                    System.out.println("Series deleted!");
                } else {
                    System.out.println("Deletion cancelled.");
                }
                return;
            }
        }
        System.out.println("Series not found.");
    }

    private static void printReport() {
        System.out.println("\n--- Series Report ---");

        if (seriesList.isEmpty()) {
            System.out.println("No series available.");
            return;
        }

        System.out.println("Total series: " + seriesList.size());
        System.out.println("----------------------");

        Series mostEpisodes = null;
        for (Series s : seriesList) {
            System.out.println(s + "\n----------------------");
            if (mostEpisodes == null || s.getNumberOfEpisodes() > mostEpisodes.getNumberOfEpisodes()) {
                mostEpisodes = s;
            }
        }

        if (mostEpisodes != null) {
            System.out.println("\nSeries with most episodes:");
            System.out.println(mostEpisodes);
        }
    }
}
