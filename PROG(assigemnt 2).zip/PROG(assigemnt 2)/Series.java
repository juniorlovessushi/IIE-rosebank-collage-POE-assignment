/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author RC_Student_lab
 */
public class Series {
    private final String id;
    private String name;
    private int ageRestriction;
    private int numberOfEpisodes;

    public Series(String id, String name, int ageRestriction, int numberOfEpisodes) {
        this.id = id;
        this.name = name;
        this.ageRestriction = ageRestriction;
        this.numberOfEpisodes = numberOfEpisodes;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAgeRestriction() {
        return ageRestriction;
    }

    public int getNumberOfEpisodes() {
        return numberOfEpisodes;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setAgeRestriction(int ageRestriction) {
        this.ageRestriction = ageRestriction;
    }

    public void setNumberOfEpisodes(int numberOfEpisodes) {
        this.numberOfEpisodes = numberOfEpisodes;
    }

    @Override
    public String toString() {
        return "SERIES ID: " + id + "\n" +
                "SERIES NAME: " + name + "\n" +
                "SERIES AGE RESTRICTION: " + ageRestriction + "\n" +
                "NUMBER OF EPISODES: " + numberOfEpisodes;
    }
}
