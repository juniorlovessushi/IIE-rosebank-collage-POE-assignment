/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author RC_Student_lab
 */
 import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class SeriesLoginMethod {
    private static ArrayList<Series> seriesList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    // ... [previous main() and displayMenu() methods remain the same] ...

    private static void captureSeries() {
        System.out.println("\nCAPTURE A NEW SERIES");
        System.out.println("*******************************");

        System.out.print("Enter the series id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the series name: ");
        String name = scanner.nextLine();

        int ageRestriction = getValidAgeRestriction();

        System.out.print("Enter the number of episodes for " + name + ": ");
        int episodes = Integer.parseInt(scanner.nextLine());

        Series newSeries = new Series(id, name, ageRestriction, episodes);
        seriesList.add(newSeries);
        System.out.println("Series processed successfully!!!");
    }

    private static int getValidAgeRestriction() {
        while (true) {
            System.out.print("Enter the series age restriction (2-18): ");
            try {
                int age = Integer.parseInt(scanner.nextLine());
                if (age >= 2 && age <= 18) {
                    return age;
                } else {
                    System.out.println("Age restriction must be between 2 and 18!");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect series age!!!");
            }
        }
    }

    private static void searchSeries() {
        System.out.print("\nEnter the series ID to search: ");
        String id = scanner.nextLine();

        for (Series series : seriesList) {
            if (series.getId().equals(id)) {
                System.out.println("\nSeries Found:");
                System.out.println(series);
                return;
            }
        }
        System.out.println("Series with Series Id: " + id + " was not found");
    }

    private static void updateSeries() {
        System.out.print("\nEnter the series ID to update: ");
        String id = scanner.nextLine();

        for (Series series : seriesList) {
            if (series.getId().equals(id)) {
                System.out.println("\nCurrent series details:");
                System.out.println(series);

                System.out.print("\nEnter new name (press enter to keep current): ");
                String newName = scanner.nextLine();
                if (!newName.isEmpty()) {
                    series.setName(newName);
                }

                System.out.print("Enter new age restriction (press enter to keep current): ");
                String ageInput = scanner.nextLine();
                if (!ageInput.isEmpty()) {
                    series.setAgeRestriction(Integer.parseInt(ageInput));
                }

                System.out.print("Enter new number of episodes (press enter to keep current): ");
                String episodesInput = scanner.nextLine();
                if (!episodesInput.isEmpty()) {
                    series.setNumberOfEpisodes(Integer.parseInt(episodesInput));
                }

                System.out.println("Series updated successfully!");
                return;
            }
        }
        System.out.println("Series with Series Id: " + id + " was not found");
    }

    private static void deleteSeries() {
        System.out.print("\nEnter the series ID to delete: ");
        String id = scanner.nextLine();

        Iterator<Series> iterator = seriesList.iterator();
        while (iterator.hasNext()) {
            Series series = iterator.next();
            if (series.getId().equals(id)) {
                System.out.print("Are you sure you want to delete series " + id + "? (Yes/No): ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("Yes")) {
                    iterator.remove();
                    System.out.println("Series with Series Id: " + id + " WAS deleted!");
                } else {
                    System.out.println("Delete cancelled.");
                }
                return;
            }
        }
        System.out.println("Series with Series Id: " + id + " was not found");
    }

    private static void printReport() {
        System.out.println("\nSERIES REPORT - 2025");
        System.out.println("*******************************");

        if (seriesList.isEmpty()) {
            System.out.println("No series available.");
            return;
        }

        int count = 1;
        for (Series series : seriesList) {
            System.out.println("\nSeries " + count++);
            System.out.println(series);
            System.out.println("-----------------------------");
        }

        System.out.println("\nTOTAL NUMBER OF SERIES CAPTURED: " + seriesList.size());

        Series topSeries = null;
        for (Series s : seriesList) {
            if (topSeries == null || s.getNumberOfEpisodes() > topSeries.getNumberOfEpisodes()) {
                topSeries = s;
            }
        }
        if (topSeries != null) {
            System.out.println("\nSERIES WITH THE MOST EPISODES");
            System.out.println(topSeries);
        }
    }
}
